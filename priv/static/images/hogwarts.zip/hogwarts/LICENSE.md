Hogwarts font is 100% free. You can use it for personal or commercial purposes.

This font was created and distributed by FontGet.com. You may freely distribute this font however you must credit FontGet.com if you do.